/**
 * Proximity - Elite Professional Networking App
 * Main JavaScript functionality for 3D interactions and shared components
 */

// Global app state and configuration
const ProximityApp = {
    version: '1.0.0',
    config: {
        radarRadius: 3,
        avatarCount: 8,
        animationDuration: 400,
        touchSensitivity: 0.01,
        pressureSensitivity: 0.5,
        maxRotationSpeed: 0.05
    },
    state: {
        isRotating: false,
        lastTouchX: 0,
        lastTouchY: 0,
        rotationX: 0,
        rotationY: 0,
        targetRotationX: 0,
        targetRotationY: 0,
        activeCard: null,
        currentPage: 'radar'
    },
    data: {
        professionals: [
            {
                name: "Sarah Chen",
                title: "Product Designer",
                company: "TechFlow Inc.",
                skills: ["UI/UX", "Prototyping", "Design Systems"],
                distance: "50m",
                avatar: "https://kimi-web-img.moonshot.cn/img/images.squarespace-cdn.com/6e26a98d03ecfb9d9d980fe946e9b3cf6a74d4e1.jpg",
                position: { x: 2, y: 1, z: 1 },
                compatibility: 94,
                status: 'active'
            },
            {
                name: "Marcus Rodriguez",
                title: "Senior Developer",
                company: "CodeLab Solutions",
                skills: ["React", "Node.js", "Cloud Architecture"],
                distance: "75m",
                avatar: "https://kimi-web-img.moonshot.cn/img/susannahfields.co.uk/36d2cb24db7165c80964407d5cdba9c1fe41162f.jpg",
                position: { x: -1.5, y: 2, z: -1 },
                compatibility: 87,
                status: 'active'
            },
            {
                name: "Emily Johnson",
                title: "Marketing Director",
                company: "Growth Dynamics",
                skills: ["Strategy", "Analytics", "Team Leadership"],
                distance: "120m",
                avatar: "https://kimi-web-img.moonshot.cn/img/metroplexheadshots.com/065c12dd70edddbdee8f4ad3e9c01fc0777bdb60.jpg",
                position: { x: 1, y: -1.5, z: 2 },
                compatibility: 91,
                status: 'busy'
            },
            {
                name: "David Kim",
                title: "Data Scientist",
                company: "AI Ventures",
                skills: ["Machine Learning", "Python", "Statistics"],
                distance: "90m",
                avatar: "https://kimi-web-img.moonshot.cn/img/images.squarespace-cdn.com/815b28fc062dcf07ecf552479d6fad3bff1c1341.jpeg",
                position: { x: -2, y: 0.5, z: 1.5 },
                compatibility: 89,
                status: 'active'
            },
            {
                name: "Lisa Thompson",
                title: "UX Researcher",
                company: "UserFirst Design",
                skills: ["User Research", "Usability Testing", "Personas"],
                distance: "65m",
                avatar: "https://kimi-web-img.moonshot.cn/img/images.squarespace-cdn.com/f4edcac7887b5e94bd1aa86bed30bfe405b3c4e1.jpg",
                position: { x: 0.5, y: 2.5, z: -0.5 },
                compatibility: 96,
                status: 'active'
            },
            {
                name: "James Wilson",
                title: "Startup Founder",
                company: "Innovation Labs",
                skills: ["Entrepreneurship", "Product Strategy", "Fundraising"],
                distance: "150m",
                avatar: "https://kimi-web-img.moonshot.cn/img/www.headshots.com/b979065b20b7caab257d54a5ac24bbdaf7792d2f.png",
                position: { x: 1.5, y: -2, z: -1.5 },
                compatibility: 83,
                status: 'active'
            },
            {
                name: "Nina Patel",
                title: "Creative Director",
                company: "Brand Studio",
                skills: ["Brand Design", "Creative Strategy", "Team Building"],
                distance: "80m",
                avatar: "https://kimi-web-img.moonshot.cn/img/image14.photobiz.com/03f09e575d3faf72eb0754d3ea9a1daaae993dcd.png",
                position: { x: -1, y: 1, z: -2 },
                compatibility: 92,
                status: 'busy'
            },
            {
                name: "Robert Chen",
                title: "Blockchain Developer",
                company: "CryptoTech Solutions",
                skills: ["Solidity", "Web3", "Smart Contracts"],
                distance: "110m",
                avatar: "https://kimi-web-img.moonshot.cn/img/images.stockcake.com/def99e0315149cb196dbccebdff2286ae340634b.jpg",
                position: { x: 2.5, y: -0.5, z: 0.5 },
                compatibility: 78,
                status: 'active'
            }
        ]
    },
    
    // Initialize the application
    init() {
        this.setupEventListeners();
        this.detectCurrentPage();
        this.initializePageSpecificFeatures();
        this.startPerformanceMonitoring();
    },
    
    // Detect current page and set state
    detectCurrentPage() {
        const path = window.location.pathname;
        if (path.includes('connections.html')) {
            this.state.currentPage = 'connections';
        } else if (path.includes('profile.html')) {
            this.state.currentPage = 'profile';
        } else {
            this.state.currentPage = 'radar';
        }
    },
    
    // Initialize page-specific features
    initializePageSpecificFeatures() {
        switch (this.state.currentPage) {
            case 'radar':
                this.initializeRadarPage();
                break;
            case 'connections':
                this.initializeConnectionsPage();
                break;
            case 'profile':
                this.initializeProfilePage();
                break;
        }
    },
    
    // Radar page initialization
    initializeRadarPage() {
        // Initialize 3D scene if on radar page
        if (typeof init3DScene === 'function') {
            init3DScene();
        }
        this.setupTouchInteractions();
        this.setupDeviceOrientation();
    },
    
    // Connections page initialization
    initializeConnectionsPage() {
        this.initializeCharts();
        this.setupFilterSystem();
        this.animateConnectionCards();
    },
    
    // Profile page initialization
    initializeProfilePage() {
        this.setupSkillVisualization();
        this.setupSettingsInteraction();
        this.animateProfileElements();
    },
    
    // Global event listeners
    setupEventListeners() {
        // Window resize handling
        window.addEventListener('resize', this.handleResize.bind(this));
        
        // Touch and gesture handling
        document.addEventListener('touchstart', this.handleTouchStart.bind(this), { passive: false });
        document.addEventListener('touchmove', this.handleTouchMove.bind(this), { passive: false });
        document.addEventListener('touchend', this.handleTouchEnd.bind(this), { passive: false });
        
        // Navigation handling
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', this.handleNavigation.bind(this));
        });
        
        // Keyboard shortcuts
        document.addEventListener('keydown', this.handleKeyboardShortcuts.bind(this));
    },
    
    // Touch interaction handling
    setupTouchInteractions() {
        const canvas = document.getElementById('radar-canvas');
        if (!canvas) return;
        
        // Enhanced touch handling with pressure simulation
        canvas.addEventListener('touchstart', (e) => {
            this.state.isRotating = true;
            const touch = e.touches[0];
            this.state.lastTouchX = touch.clientX;
            this.state.lastTouchY = touch.clientY;
            
            // Simulate pressure sensitivity
            const pressure = touch.force || 0.5;
            this.handlePressureChange(pressure);
        });
        
        canvas.addEventListener('touchmove', (e) => {
            if (!this.state.isRotating) return;
            
            const touch = e.touches[0];
            const deltaX = touch.clientX - this.state.lastTouchX;
            const deltaY = touch.clientY - this.state.lastTouchY;
            
            // Apply sensitivity configuration
            this.state.targetRotationY += deltaX * this.config.touchSensitivity;
            this.state.targetRotationX += deltaY * this.config.touchSensitivity;
            
            // Limit rotation speed
            this.state.targetRotationX = Math.max(
                -this.config.maxRotationSpeed,
                Math.min(this.config.maxRotationSpeed, this.state.targetRotationX)
            );
            this.state.targetRotationY = Math.max(
                -this.config.maxRotationSpeed,
                Math.min(this.config.maxRotationSpeed, this.state.targetRotationY)
            );
            
            this.state.lastTouchX = touch.clientX;
            this.state.lastTouchY = touch.clientY;
        });
        
        canvas.addEventListener('touchend', () => {
            this.state.isRotating = false;
        });
    },
    
    // Device orientation handling
    setupDeviceOrientation() {
        if (window.DeviceOrientationEvent) {
            window.addEventListener('deviceorientation', (e) => {
                if (e.beta && e.gamma) {
                    // Apply tilt-based rotation with smoothing
                    const tiltX = e.beta * 0.01;
                    const tiltY = e.gamma * 0.01;
                    
                    this.state.targetRotationX += (tiltX - this.state.targetRotationX) * 0.1;
                    this.state.targetRotationY += (tiltY - this.state.targetRotationY) * 0.1;
                }
            });
        }
    },
    
    // Handle pressure changes (simulated)
    handlePressureChange(pressure) {
        // Adjust interaction intensity based on pressure
        const intensity = pressure * this.config.pressureSensitivity;
        
        // Update visual feedback based on pressure
        const avatarNodes = document.querySelectorAll('.avatar-node, .connection-avatar');
        avatarNodes.forEach(node => {
            node.style.filter = `brightness(${1 + intensity * 0.2})`;
        });
    },
    
    // Touch event handlers
    handleTouchStart(e) {
        if (e.target.closest('#radar-canvas')) {
            this.state.isRotating = true;
            const touch = e.touches[0];
            this.state.lastTouchX = touch.clientX;
            this.state.lastTouchY = touch.clientY;
        }
    },
    
    handleTouchMove(e) {
        if (!this.state.isRotating) return;
        
        const touch = e.touches[0];
        const deltaX = touch.clientX - this.state.lastTouchX;
        const deltaY = touch.clientY - this.state.lastTouchY;
        
        this.state.targetRotationY += deltaX * this.config.touchSensitivity;
        this.state.targetRotationX += deltaY * this.config.touchSensitivity;
        
        this.state.lastTouchX = touch.clientX;
        this.state.lastTouchY = touch.clientY;
        
        e.preventDefault(); // Prevent scrolling
    },
    
    handleTouchEnd(e) {
        this.state.isRotating = false;
    },
    
    // Window resize handler
    handleResize() {
        // Update responsive elements
        if (typeof updateLayout === 'function') {
            updateLayout();
        }
        
        // Recalculate touch targets
        this.recalculateTouchTargets();
    },
    
    // Recalculate touch targets for responsive design
    recalculateTouchTargets() {
        const touchTargets = document.querySelectorAll('.nav-item, .action-btn, .skill-node');
        
        touchTargets.forEach(target => {
            const rect = target.getBoundingClientRect();
            target.dataset.touchSize = Math.min(rect.width, rect.height);
        });
    },
    
    // Navigation handling
    handleNavigation(e) {
        const navItem = e.currentTarget;
        const href = navItem.getAttribute('href');
        
        // Add navigation animation
        anime({
            targets: navItem,
            scale: [1, 0.95, 1],
            duration: 200,
            easing: 'easeOutCubic'
        });
        
        // Update active state
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.remove('active');
        });
        navItem.classList.add('active');
        
        // Simulate page transition
        this.transitionToPage(href);
    },
    
    // Page transition animation
    transitionToPage(href) {
        // Create transition overlay
        const overlay = document.createElement('div');
        overlay.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background: linear-gradient(135deg, #FEFCF8 0%, #F7F3E9 100%);
            z-index: 10000;
            opacity: 0;
            pointer-events: none;
        `;
        
        document.body.appendChild(overlay);
        
        // Animate transition
        anime({
            targets: overlay,
            opacity: [0, 1],
            duration: 300,
            easing: 'easeOutCubic',
            complete: () => {
                // Navigate to new page
                window.location.href = href;
            }
        });
    },
    
    // Keyboard shortcuts
    handleKeyboardShortcuts(e) {
        // Global keyboard shortcuts
        switch (e.key) {
            case 'r':
                if (e.ctrlKey || e.metaKey) {
                    e.preventDefault();
                    this.resetView();
                }
                break;
            case 'h':
                if (e.ctrlKey || e.metaKey) {
                    e.preventDefault();
                    this.toggleHelp();
                }
                break;
            case 'Escape':
                this.closeActiveElements();
                break;
        }
    },
    
    // Reset view to default state
    resetView() {
        this.state.targetRotationX = 0;
        this.state.targetRotationY = 0;
        this.closeActiveElements();
        
        // Animate reset
        anime({
            targets: [this.state],
            rotationX: 0,
            rotationY: 0,
            duration: 800,
            easing: 'easeOutCubic'
        });
    },
    
    // Close active elements (cards, modals)
    closeActiveElements() {
        const activeElements = document.querySelectorAll('.bio-card.active, .modal.active');
        activeElements.forEach(element => {
            element.classList.remove('active');
        });
        
        this.state.activeCard = null;
    },
    
    // Toggle help overlay
    toggleHelp() {
        const existingHelp = document.querySelector('.help-overlay');
        
        if (existingHelp) {
            anime({
                targets: existingHelp,
                opacity: 0,
                duration: 300,
                complete: () => existingHelp.remove()
            });
        } else {
            this.showHelpOverlay();
        }
    },
    
    // Show help overlay
    showHelpOverlay() {
        const helpOverlay = document.createElement('div');
        helpOverlay.className = 'help-overlay';
        helpOverlay.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background: rgba(0, 0, 0, 0.8);
            z-index: 10000;
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0;
        `;
        
        helpOverlay.innerHTML = `
            <div style="
                background: white;
                padding: 32px;
                border-radius: 20px;
                max-width: 400px;
                text-align: center;
                box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            ">
                <h3 style="margin-bottom: 16px; color: #2C2C2C;">Proximity Help</h3>
                <div style="text-align: left; color: #666; line-height: 1.6;">
                    <p><strong>Touch & Drag:</strong> Rotate the radar sphere</p>
                    <p><strong>Tap Avatars:</strong> View professional profiles</p>
                    <p><strong>Tilt Device:</strong> Adjust 3D perspective</p>
                    <p><strong>Keyboard:</strong> Ctrl+R (Reset), Ctrl+H (Help)</p>
                </div>
                <button onclick="this.closest('.help-overlay').remove()" style="
                    margin-top: 20px;
                    padding: 12px 24px;
                    background: #D4AF37;
                    color: white;
                    border: none;
                    border-radius: 12px;
                    cursor: pointer;
                    font-weight: 600;
                ">Got it!</button>
            </div>
        `;
        
        document.body.appendChild(helpOverlay);
        
        anime({
            targets: helpOverlay,
            opacity: 1,
            duration: 300,
            easing: 'easeOutCubic'
        });
    },
    
    // Initialize charts for connections page
    initializeCharts() {
        if (typeof initChart === 'function') {
            initChart();
        }
    },
    
    // Setup filter system for connections
    setupFilterSystem() {
        if (typeof setupFilterTabs === 'function') {
            setupFilterTabs();
        }
    },
    
    // Animate connection cards
    animateConnectionCards() {
        const cards = document.querySelectorAll('.connection-card');
        
        anime({
            targets: cards,
            translateY: [40, 0],
            opacity: [0, 1],
            delay: anime.stagger(100),
            duration: 600,
            easing: 'easeOutCubic'
        });
    },
    
    // Setup skill visualization for profile page
    setupSkillVisualization() {
        if (typeof setupSkillNodes === 'function') {
            setupSkillNodes();
        }
    },
    
    // Setup settings interaction for profile page
    setupSettingsInteraction() {
        if (typeof setupToggleSwitches === 'function') {
            setupToggleSwitches();
        }
        if (typeof setupRangeSliders === 'function') {
            setupRangeSliders();
        }
    },
    
    // Animate profile elements
    animateProfileElements() {
        const profileCard = document.querySelector('.profile-card');
        const sections = document.querySelectorAll('.section');
        
        if (profileCard) {
            anime({
                targets: profileCard,
                translateY: [50, 0],
                opacity: [0, 1],
                duration: 800,
                easing: 'easeOutCubic'
            });
        }
        
        if (sections.length) {
            anime({
                targets: sections,
                translateY: [40, 0],
                opacity: [0, 1],
                delay: anime.stagger(200),
                duration: 700,
                easing: 'easeOutCubic'
            });
        }
    },
    
    // Performance monitoring
    startPerformanceMonitoring() {
        // Monitor frame rate
        let lastTime = performance.now();
        let frameCount = 0;
        
        const monitorFrameRate = (currentTime) => {
            frameCount++;
            
            if (currentTime - lastTime >= 1000) {
                const fps = Math.round((frameCount * 1000) / (currentTime - lastTime));
                
                // Adjust quality based on performance
                if (fps < 30) {
                    this.reduceQuality();
                } else if (fps > 55) {
                    this.increaseQuality();
                }
                
                frameCount = 0;
                lastTime = currentTime;
            }
            
            requestAnimationFrame(monitorFrameRate);
        };
        
        requestAnimationFrame(monitorFrameRate);
    },
    
    // Reduce visual quality for performance
    reduceQuality() {
        document.body.classList.add('reduced-quality');
        
        // Reduce particle count
        const particles = document.querySelectorAll('.particle');
        particles.forEach((particle, index) => {
            if (index % 2 === 0) {
                particle.style.display = 'none';
            }
        });
    },
    
    // Increase visual quality when performance allows
    increaseQuality() {
        document.body.classList.remove('reduced-quality');
        
        // Restore particles
        const particles = document.querySelectorAll('.particle');
        particles.forEach(particle => {
            particle.style.display = 'block';
        });
    },
    
    // Utility functions
    utils: {
        // Smooth interpolation
        lerp(start, end, factor) {
            return start + (end - start) * factor;
        },
        
        // Clamp value between min and max
        clamp(value, min, max) {
            return Math.min(Math.max(value, min), max);
        },
        
        // Generate random ID
        generateId() {
            return Math.random().toString(36).substr(2, 9);
        },
        
        // Format distance
        formatDistance(meters) {
            if (meters < 1000) {
                return `${meters}m`;
            } else {
                return `${(meters / 1000).toFixed(1)}km`;
            }
        },
        
        // Calculate compatibility score
        calculateCompatibility(userSkills, targetSkills) {
            const commonSkills = userSkills.filter(skill => 
                targetSkills.some(targetSkill => 
                    targetSkill.toLowerCase().includes(skill.toLowerCase()) ||
                    skill.toLowerCase().includes(targetSkill.toLowerCase())
                )
            );
            
            const compatibility = (commonSkills.length / Math.max(userSkills.length, targetSkills.length)) * 100;
            return Math.round(compatibility);
        },
        
        // Debounce function
        debounce(func, wait) {
            let timeout;
            return function executedFunction(...args) {
                const later = () => {
                    clearTimeout(timeout);
                    func(...args);
                };
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
            };
        },
        
        // Throttle function
        throttle(func, limit) {
            let inThrottle;
            return function() {
                const args = arguments;
                const context = this;
                if (!inThrottle) {
                    func.apply(context, args);
                    inThrottle = true;
                    setTimeout(() => inThrottle = false, limit);
                }
            };
        }
    },
    
    // Notification system
    notifications: {
        show(message, type = 'info', duration = 3000) {
            const notification = document.createElement('div');
            notification.className = `notification notification-${type}`;
            notification.textContent = message;
            
            const colors = {
                info: 'rgba(0, 0, 0, 0.8)',
                success: '#98FB98',
                warning: '#FFB347',
                error: '#FF6B6B'
            };
            
            notification.style.cssText = `
                position: fixed;
                top: 20px;
                left: 50%;
                transform: translateX(-50%);
                background: ${colors[type]};
                color: white;
                padding: 12px 24px;
                border-radius: 12px;
                font-size: 14px;
                z-index: 10000;
                pointer-events: none;
                opacity: 0;
                max-width: 90vw;
                text-align: center;
            `;
            
            document.body.appendChild(notification);
            
            anime({
                targets: notification,
                opacity: [0, 1],
                translateY: [-20, 0],
                duration: 300,
                easing: 'easeOutCubic',
                complete: () => {
                    setTimeout(() => {
                        anime({
                            targets: notification,
                            opacity: 0,
                            translateY: -20,
                            duration: 200,
                            complete: () => notification.remove()
                        });
                    }, duration);
                }
            });
        }
    }
};

// Initialize app when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    ProximityApp.init();
});

// Export for global access
window.ProximityApp = ProximityApp;